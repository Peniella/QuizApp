package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
public  static final String  EXTRA_TEXT = "Score";
    protected static int sum1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        sum1 = intent.getExtras().getInt(EXTRA_TEXT);
        TextView text = (TextView) findViewById(R.id.score);
        text.setText("Score: " + (Integer.toString(sum1)));
    }

    public void next(View view){

        RadioButton correct2 = (RadioButton) findViewById(R.id.correct2);
        RadioButton wrong2 = (RadioButton) findViewById(R.id.wrong2);
        boolean canswer2 = correct2.isChecked();
        boolean wanswer2 = wrong2.isChecked();
        int score2 = calculateScore(canswer2, wanswer2, sum1);
        Intent intent = new Intent(this, Main3Activity.class);
        intent.putExtra(Main3Activity.EXTRA_TEXT, score2);
        startActivity(intent);

        if(canswer2){
            displayCoin();
        }

    }

    private int calculateScore( boolean answer2, boolean incorrect2, int sum){
        int score = sum;
        if(answer2)
        {
            score = score + 10;
        }
        if (incorrect2){
            score = score + 0;
        }
        return score;
    }

    private void displayCoin(){
        LinearLayout layout = new LinearLayout(getBaseContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);
        Toast imageToast = new Toast(this);
        ImageView image = new ImageView(getBaseContext());
        image.setImageResource(R.drawable.score);
        layout.addView(image);
        imageToast.setView(layout);
        imageToast.setDuration(Toast.LENGTH_SHORT);
        imageToast.show();
    }



}