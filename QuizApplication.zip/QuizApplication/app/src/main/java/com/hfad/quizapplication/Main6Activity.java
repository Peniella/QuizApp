package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Main6Activity extends AppCompatActivity {

    public static String EXTRA_TEXT = "Score";
    protected int TotalScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        Intent intent = getIntent();
        TotalScore = intent.getExtras().getInt(EXTRA_TEXT);

        if(TotalScore>25){
            excellent();
            TextView text = (TextView) findViewById(R.id.grade);
            text.setText("Wow! You did excellently well" + "\nYour Score is " + (Integer.toString(TotalScore)));
        }
        else if(TotalScore==25){
            average();
            TextView text = (TextView) findViewById(R.id.grade);
            text.setText("Wow! You tried\t" + "\nYour Score is " + (Integer.toString(TotalScore)));
        }
        else {
            poor();
            TextView text = (TextView) findViewById(R.id.grade);
            text.setText("Oops! You didn't perform well enough" + "\nYour Score is " +(Integer.toString(TotalScore)));
        }
    }

    public void endButton(View view){
    finish();
    moveTaskToBack(true);
    }

    private void excellent(){
        ImageView image = (ImageView) findViewById(R.id.emotion);
        image.setImageResource(R.drawable.excellent);
    }

    private void average(){
        ImageView image = (ImageView) findViewById(R.id.emotion);
        image.setImageResource(R.drawable.average);
    }

    private void poor(){
        ImageView image = (ImageView) findViewById(R.id.emotion);
        image.setImageResource(R.drawable.poor);
    }
}
