package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void next(View view){

        RadioButton correct1 = (RadioButton) findViewById(R.id.correct1);
        RadioButton wrong1 = (RadioButton) findViewById(R.id.wrong1);
        boolean canswer1 = correct1.isChecked();
        boolean wanswer1 = wrong1.isChecked();
        int score1 = calculateScore(canswer1, wanswer1);
        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra(Main2Activity.EXTRA_TEXT, score1);
        startActivity(intent);
        //displayScore(score1);
        if(canswer1){
            displayCoin();
        }

    }

    private int calculateScore( boolean answer1, boolean incorrect1){
    int score = 0;
        if(answer1)
        {
            score = score + 10;
        }
        if (incorrect1){
            score = score + 0;
        }
    return score;
    }

    private void displayCoin(){
        LinearLayout layout = new LinearLayout(getBaseContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);
        Toast imageToast = new Toast(this);
        ImageView image = new ImageView(getBaseContext());
        image.setImageResource(R.drawable.score);
        layout.addView(image);
        imageToast.setView(layout);
        imageToast.setDuration(Toast.LENGTH_SHORT);
        imageToast.show();
    }


}
