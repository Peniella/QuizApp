package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "Score";
    protected static int sum2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        sum2 = intent.getExtras().getInt(EXTRA_TEXT);
        TextView text = (TextView) findViewById(R.id.score);
        text.setText("Score: " + (Integer.toString(sum2)));
    }

    public void next(View view){

        RadioButton correct3 = (RadioButton) findViewById(R.id.correct3);
        RadioButton wrong3 = (RadioButton) findViewById(R.id.wrong3);
        boolean canswer3 = correct3.isChecked();
        boolean wanswer3 = wrong3.isChecked();
        int score3 = calculateScore(canswer3, wanswer3, sum2);
        Intent intent = new Intent(this, Main4Activity.class);
        intent.putExtra(Main4Activity.EXTRA_TEXT, score3);
        startActivity(intent);


        if(canswer3){
            displayCoin();
        }

    }

    private int calculateScore( boolean answer3, boolean incorrect3, int sum){
        int score = sum;
        if(answer3)
        {
            score = score + 10;
        }
        if (incorrect3){
            score = score + 0;
        }
        return score;
    }

    private void displayCoin(){
        LinearLayout layout = new LinearLayout(getBaseContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);
        // ImageView imageView = new ImageView(this);
        Toast imageToast = new Toast(this);
        ImageView image = new ImageView(getBaseContext());
        image.setImageResource(R.drawable.score);
        layout.addView(image);
        imageToast.setView(layout);
        imageToast.setDuration(Toast.LENGTH_SHORT);
        imageToast.show();
    }



}
