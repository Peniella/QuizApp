package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Main5Activity extends AppCompatActivity {

    public static String EXTRA_TEXT = "Score";
    protected int sum4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Intent intent = getIntent();
        sum4 = intent.getExtras().getInt(EXTRA_TEXT);
        TextView text = (TextView) findViewById(R.id.score);
        text.setText("Score: " + (Integer.toString(sum4)));
    }

    public void next(View view){

        RadioButton correct5 = (RadioButton) findViewById(R.id.correct5);
        RadioButton wrong5 = (RadioButton) findViewById(R.id.wrong5);
        boolean canswer5 = correct5.isChecked();
        boolean wanswer5 = wrong5.isChecked();
        int score5 = calculateScore(canswer5, wanswer5, sum4);
        Intent intent = new Intent(this, Main6Activity.class);
        intent.putExtra(Main6Activity.EXTRA_TEXT, score5);
        startActivity(intent);


        if(canswer5){
            displayCoin();
        }

    }

    private int calculateScore( boolean answer5, boolean incorrect5, int sum){
        int score = sum;
        if(answer5)
        {
            score = score + 10;
        }
        if (incorrect5){
            score = score + 0;
        }
        return score;
    }

    private void displayCoin(){
        LinearLayout layout = new LinearLayout(getBaseContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);
        Toast imageToast = new Toast(this);
        ImageView image = new ImageView(getBaseContext());
        image.setImageResource(R.drawable.score);
        layout.addView(image);
        imageToast.setView(layout);
        imageToast.setDuration(Toast.LENGTH_SHORT);
        imageToast.show();
    }

}
