package com.hfad.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {

    public static String EXTRA_TEXT ="Score";
    protected int sum3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        Intent intent = getIntent();
        sum3 = intent.getExtras().getInt(EXTRA_TEXT);
        TextView text = (TextView) findViewById(R.id.score);
        text.setText("Score: " + (Integer.toString(sum3)));
    }

    public void next(View view){

        RadioButton correct4 = (RadioButton) findViewById(R.id.correct4);
        RadioButton wrong4 = (RadioButton) findViewById(R.id.wrong4);
        boolean canswer4 = correct4.isChecked();
        boolean wanswer4 = wrong4.isChecked();
        int score4 = calculateScore(canswer4, wanswer4, sum3);
        Intent intent = new Intent(this, Main5Activity.class);
        intent.putExtra(Main5Activity.EXTRA_TEXT, score4);
        startActivity(intent);


        if(canswer4){
            displayCoin();
        }

    }

    private int calculateScore( boolean answer4, boolean incorrect4, int sum){
        int score = sum;
        if(answer4)
        {
            score = score + 10;
        }
        if (incorrect4){
            score = score + 0;
        }
        return score;
    }

    private void displayCoin(){
        LinearLayout layout = new LinearLayout(getBaseContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);
        Toast imageToast = new Toast(this);
        ImageView image = new ImageView(getBaseContext());
        image.setImageResource(R.drawable.score);
        layout.addView(image);
        imageToast.setView(layout);
        imageToast.setDuration(Toast.LENGTH_SHORT);
        imageToast.show();
    }


}

